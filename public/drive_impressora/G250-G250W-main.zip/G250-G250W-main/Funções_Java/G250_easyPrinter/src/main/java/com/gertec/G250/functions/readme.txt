Projeto: G250 – Easy Print 
Linguagem: Java

Para Execução das funções é necessário adicionar os arquivos de funções ao seu projeto Java desenvolvido em sua IDE de preferência. 

Um arquivo java com método main foi adicionado a pasta dependências e testes para exemplificar a utilização das funções.


obs: Os teste realizados até o momento foram utilizando a IDE NetBeans 12.4, no windows - para testes via cabo usb e rede - no linux testes via rede e no Android Studio 2021.1.1 em teste via rede.
obs: Os testes via cabo usb foram realizados na porta Com e utilizando o spool do Windows (para a impressora conectada como UTP)