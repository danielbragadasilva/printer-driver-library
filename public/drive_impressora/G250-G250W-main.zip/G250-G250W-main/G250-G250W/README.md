[![EKzBdw7WwAQrq8J (1) (1)](https://github.com/gertecdeveloper/GBot/assets/60237221/a22d4737-43c9-4721-8acf-ca5fff58322f)](https://www.gertec.com.br/)

----------------------------------------------------------------------

 <h1 align="center">                        ! Atenção !</h1>            
 
  ----------------------------------------------------------------------

 # O Jira é portal oficial da Gertec para exemplos e documentações de todos os nossos produtos. 
 
<h2 align="left"> Link abaixo: </h2> 
 
 https://gertec.atlassian.net/servicedesk/customer/portal/26
 
 ----------------------------------------------------------------------

# Manuais para a impressora G250
<h2 align="left"> Link abaixo: </h2> 

https://gertec.atlassian.net/servicedesk/customer/portal/26/topic/5f984863-3a75-4465-abd8-637f16e238ba


