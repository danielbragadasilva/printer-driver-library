package com.dantsu.escposprinter.exceptions;

public class EscPosEncodingException extends Exception {
    public EscPosEncodingException(String errorMessage) {
        super(errorMessage);
    }
}
